package cn.edu.sustech.cs307.datamanager;

import java.util.List;

public abstract class DataManager {

	public abstract void init(List<DataRecord> records);
	
}
