drop table if exists import_information;

drop table if exists export_information;

drop table if exists delivery_information;

drop table if exists retrieval_information;

drop table if exists item;

drop table if exists container;

drop table if exists ship;

drop table if exists courier;