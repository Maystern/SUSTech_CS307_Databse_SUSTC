package cn.edu.sustech.dbms2.client.packet;

public abstract class Packet {

	public abstract String getContext();

	public abstract int getCode();

}
