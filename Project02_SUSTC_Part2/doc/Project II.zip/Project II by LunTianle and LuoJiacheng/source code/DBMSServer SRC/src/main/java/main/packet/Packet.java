package main.packet;

public abstract class Packet {

	public abstract String getContext();

	public abstract int getCode();

}
